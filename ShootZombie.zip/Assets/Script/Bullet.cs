using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public int damage = 20;           // Damage dealt by the bullet
    public float lifetime = 3f;       // Time in seconds before the bullet is destroyed automatically

    void Start()
    {
        // Destroy the bullet automatically after 'lifetime' seconds
        Destroy(gameObject, lifetime);
    }

    void OnCollisionEnter(Collision collision)
    {
        // Check if the object the bullet hit has an EnemyHealth component
        EnemyHealth enemyHealth = collision.gameObject.GetComponent<EnemyHealth>();

        if (enemyHealth != null)
        {
            // Apply damage to the enemy
            enemyHealth.TakeDamage(damage);

            // Destroy the bullet after it hits an enemy
            Destroy(gameObject);
        }
        else if (collision.gameObject.CompareTag("Floor"))
        {
            // Destroy the bullet if it hits the floor
            Destroy(gameObject);
        }
    }
}
