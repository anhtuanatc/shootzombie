using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public GameObject enemyPrefab;       // The enemy prefab to spawn
    public Transform spawnPoints;      // Array to hold all the spawn points
    public float spawnDelay = 2f;        // Time before spawning starts
    public float spawnInterval = 5f;     // Time between each spawn
    public Transform player;             // Reference to the player's Transform

    void Start()
    {
        // Start repeatedly spawning enemies
        InvokeRepeating("SpawnEnemy", spawnDelay, spawnInterval);
    }

    void SpawnEnemy()
    {


        // Instantiate the enemy at the chosen spawn point's position and rotation
        GameObject enemy = Instantiate(enemyPrefab, spawnPoints.position, spawnPoints.rotation);

        // Set the player's Transform in the EnemyAI script
        EnemyAI enemyAI = enemy.GetComponent<EnemyAI>();
        if (enemyAI != null)
        {
            enemyAI.SetPlayer(player);
        }
    }
}
